package com.BmICALCU;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class viewstud extends Activity
{
  Button btnvstudsubmit;
  Spinner spincourse,spinyear;
  
	String[] course = new String[]{"BSIT","BSCS","BSMATH","BSIP","BSAP"};
	String[] year = new String[]{"4th ","3rd" ,"2nd","1st"};
	
  
  
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewstud);
		
		Button btnvstudsubmit = findViewById(R.id.vstudsubmit)                  ;
		spincourse =findViewById(R.id.courseID);
		spinyear=findViewById(R.id.yearID);
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this , R.layout.logintextview,course);
		spincourse.setAdapter(adapter);
		
		ArrayAdapter<String> adapters = new ArrayAdapter<String>(this , R.layout.logintextview,year);
		spinyear.setAdapter(adapters);
		
		
		btnvstudsubmit.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(viewstud.this,studentlist.class);
					startActivity(intent);
				}
				
			
		});
}
}

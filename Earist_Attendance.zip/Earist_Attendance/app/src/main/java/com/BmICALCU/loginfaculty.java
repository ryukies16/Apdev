package com.BmICALCU;
import android.app.Activity;
import android.os.Bundle;

public class loginfaculty extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loginfaculty);
		}
}

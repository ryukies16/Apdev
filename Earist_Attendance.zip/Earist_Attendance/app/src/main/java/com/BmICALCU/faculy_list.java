package com.BmICALCU;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;


	public class faculy_list extends Activity
	{
		Button baddstud,bvstud,battperstud,btnaddfacu,btnvfacu,btnlogout;

		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			// TODO: Implement this method
			super.onCreate(savedInstanceState);
			setContentView(R.layout.faculy_list);
		}	
}


package com.BmICALCU;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.text.Layout;
import android.widget.Spinner;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.lang.reflect.Array;
import android.widget.AdapterView;
import android.widget.Adapter;

public class login extends Activity
{
	Button btn1;
	Spinner spinner;
	String[] earist = new String[]{"Admin","Faculty"};

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		Button btn1 =findViewById(R.id.logbtn1);
		spinner =findViewById(R.id.loginspin);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this , R.layout.logintextview,earist);
		spinner.setAdapter(adapter);
		
		
		
		
		
		
		
		btn1.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent (login.this,admin.class)                          ;
					startActivity(intent);	
				}


			});
			
			
			
			
			
			
			
	}
	public void SelectSpinnerValue (View view){
		spinner.setSelection(2);
	}
	
}

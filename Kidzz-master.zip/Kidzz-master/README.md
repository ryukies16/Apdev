# Kidzz
Android app for kids

# ScreenShot
<img src="ScreenShot/screen1.jpg" width="40%">
<img src="ScreenShot/screen2.jpg" width="40%">
<img src="ScreenShot/screen3.jpg" width="40%">
<img src="ScreenShot/screen4.jpg" width="40%">
<img src="ScreenShot/screen5.jpg" width="40%">
<img src="ScreenShot/screen6.jpg" width="40%">


# Tools library

Here you can find ready to use tools for your Android Academy based app. Tools include java, layout and drawable files.

If you develop a tool by yourself, please do share it here to help other educators.

## Tools list:

* __[Password vault:](password_vault)__ users will be able to save safely all their passwords safely in one place and access them with a single password.

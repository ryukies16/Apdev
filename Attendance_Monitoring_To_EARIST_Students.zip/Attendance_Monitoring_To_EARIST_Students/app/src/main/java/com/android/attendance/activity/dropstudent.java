package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.fragment.R;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.android.attendance.bean.AttendanceBean;
import com.android.attendance.bean.StudentBean;
import com.android.attendance.context.ApplicationContext;
import com.android.attendance.db.DBAdapter;
import java.util.ArrayList;

public class dropstudent extends Activity
{
	
	ListView list;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.blank);
		

		list=(ListView)findViewById(R.id.listdrop);
		final ArrayList<String> attendanceList = new ArrayList<String>();
		attendanceList.add("Student_No | StudentName |  Status");
	
		ArrayList<AttendanceBean> attendanceBeanList=((ApplicationContext)dropstudent.this.getApplicationContext()).getAttendanceBeanList();

		for (AttendanceBean attendanceBean : attendanceBeanList)
		{
			String users = "";
			if(attendanceBean.getAttendance_session_id() != 0)
			{
				DBAdapter dbAdapter = new DBAdapter(dropstudent.this);
				StudentBean studentBean =dbAdapter.getStudentById(attendanceBean.getAttendance_student_id());
				users = studentBean.getStudent_number()+".     "+studentBean.getStudent_firstname()+","+studentBean.getStudent_lastname()+"                  "+attendanceBean.getAttendance_status();
			}
			else
			{
				users = attendanceBean.getAttendance_status();
			}

			attendanceList.add(users);
			Log.d("users: ", users); 

		}
		

		ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, R.layout.view_attendance_list, R.id.labelAttendance, attendanceList);
		list.setAdapter(listAdapter); 
	}
}

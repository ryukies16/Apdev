Summer 2016

This is an android application prototype built with android studio. The application Keeps track of category related tasks by their due dates using a simple and easy-to-use interface.

The current build includes a date picker, color coded editable categories, a sorted list of created tasks, a trash area for deleted tasks, and more. Future implementation was to include saving the tasks using SQL, a settings dropdown from the top right corner, full functionality of the TrashActivity, and more. There are no Unit Tests for this program; however, if I were to continue development I would begin by adding tests for current and future code.

The intent of this was for personal use only. I was going to use it to keep track of School work and other small tasks; however, I eventually decided that there were many other android applications on the app store that could suite my needs done by professional companies such as Google. Hence, I halted development on Due-Dates.

With that said, I really enjoyed working on this application and could pick it back up in the future given that I have more time to work on it and make it more "professional". At the very least, the learning experience of getting this far with Due-Dates was worth the effort.

Furthermore, this repository only contains the source code and does not contain the entire build.
